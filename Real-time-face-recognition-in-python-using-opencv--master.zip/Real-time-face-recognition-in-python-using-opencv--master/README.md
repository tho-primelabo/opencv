# Real-time-face-recognition-in-python-using-opencv-
Real time face recognition in python using opencv, Opencv 2.4.10, python 2.7.10,Numpy 1.11.0

make folder name "database" 

Run the create_data.py, make 10 to 12 datasets

Now Run the face_recognize.py 
